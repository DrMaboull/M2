package indexation.content;

/**
 * Représente un token, i.e. un couple
 * (mot,numéro) de document.
 */
public class Token implements Comparable<Token>
{	/**
	 * Crée un nouveau token à partir
	 * du type et du numéro de document
	 * passés en paramètres.
	 * 
	 * @param type
	 * 		Type dont le token est une occurrence.
	 * @param docId
	 * 		Numéro du document concerné.
	 */
	public Token(String type, int docId)
	{	//TODO méthode à compléter (TP1-ex2)
		//TODO méthode à modifier  (TP5-ex2)
	}
	
	////////////////////////////////////////////////////
	//	TYPE
	////////////////////////////////////////////////////
	/** Type associé au token */
	//TODO champ à créer (TP1-ex2)
	
	////////////////////////////////////////////////////
	//	DOC ID
	////////////////////////////////////////////////////
	/** Numéro du document contenant le token */
	//TODO champ à créer (TP1-ex2)
	
	////////////////////////////////////////////////////
	//	POSITION
	////////////////////////////////////////////////////
	/** Position du token dans le document */
	//TODO champ à créer (TP5-ex2)
	
	////////////////////////////////////////////////////
	//	COMPARABLE
	////////////////////////////////////////////////////
	@Override
	public int compareTo(Token token)
	{	int result = 0;
		//TODO méthode à compléter (TP1-ex3)
		//TODO méthode à modifier  (TP5-ex1)
		return result;
	}
	
	////////////////////////////////////////////////////
	//	OBJECT
	////////////////////////////////////////////////////
	@Override
	public String toString()
	{	String result = null;
		//TODO méthode à compléter (TP1-ex4)
		//TODO méthode à modifier  (TP5-ex1)
		return result;
	}
	
	@Override
	public boolean equals(Object o)
	{	boolean result = false;
		//TODO méthode à compléter (TP1-ex4)
		return result;
	}
	
	////////////////////////////////////////////////////
	//	TEST
	////////////////////////////////////////////////////
	public static void main(String[] args) 
	{	// test du constructeur et de toString
		// TODO méthode à compléter (TP1-ex4)
		
		// test de equals
		// TODO méthode à compléter (TP1-ex4)
				
		// test de compareTo
		// TODO méthode à compléter (TP1-ex4)
	}
}
